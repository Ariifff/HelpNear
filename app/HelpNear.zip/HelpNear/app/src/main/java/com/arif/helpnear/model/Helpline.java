package com.arif.helpnear;

public class Helpline {
    public String title;
    public String number;

    public Helpline() { }

    public Helpline(String title, String number) {
        this.title = title;
        this.number = number;
    }
}
